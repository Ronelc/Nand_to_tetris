"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import os
import typing
from Parser import *

operator_dict = {
    "and": "&",
    "add": "+",
    "or": "|",
    "sub": "-"
}

shift_dict = {
    "shiftleft": "<<",
    "shiftright": ">>"
}

compare_dict = {
    "eq": "JEQ",
    "gt": "JLT",
    "lt": "JGT"
}

self_switch_dict = {
    "neg": "-",
    "not": "!"
}

segment_dict = {
    "local": "LCL",
    "argument": "ARG",
    "this": "THIS",
    "that": "THAT",
    "temp": "R5",
    "pointer": "R3"
}


class CodeWriter:
    """Translates VM commands into Hack assembly code."""

    def __init__(self, output_stream: typing.TextIO) -> None:
        """Initializes the CodeWriter.

        Args:
            output_stream (typing.TextIO): output stream.
        """
        # Your code goes here!
        self.out_file = output_stream
        self.num_of_func = 0
        self.file_name = ""


    def read_file(self,  input_file: typing.TextIO):
        p = Parser(input_file)
        while p.has_more_commands():
            c_type = p.command_type()
            if c_type == "C_ARITHMETIC":
                self.write_arithmetic(p.arg1())
            if c_type == "C_PUSH" or c_type == "C_POP":
                self.write_push_pop(p.arg1(), p.segment(),
                                    p.segment_index())
            p.advance()
        c_type = p.command_type()
        if c_type == "C_ARITHMETIC":
            self.write_arithmetic(p.arg1())
        if c_type == "C_PUSH" or c_type == "C_POP":
            self.write_push_pop(p.arg1(), p.segment(),
                                p.segment_index())


    def set_file_name(self, filename: str) -> None:
        """Informs the code writer that the translation of a new VM file is 
        started.

        Args:
            filename (str): The name of the VM file.
        """
        self.file_name, input_extension = os.path.splitext(
            os.path.basename(filename))


    def write_arithmetic(self, command: str) -> None:
        """Writes the assembly code that is the translation of the given 
        arithmetic command.

        Args:
            command (str): an arithmetic command.
        """
        # Your code goes here!

        if command in operator_dict:

            # sets pointer to first value
            self.out_file.write("@SP\n"
                                "A=M\n"
                                "A=A-1\n")

            # saves first value and goes to next value and
            # adds it to next value
            self.out_file.write("D=M\n"
                                "A=A-1\n"
                                "M=M" + operator_dict.get(command) + "D\n")

            # lowers value of pointer
            self.out_file.write("@SP\n"
                                "M=M-1\n")

        elif command in shift_dict:

            # sets pointer to first value
            self.out_file.write("@SP\n"
                                "A=M\n"
                                "A=A-1\n")

            # saves first value and goes to next value and
            # adds it to next value
            self.out_file.write(
                                "M="+ shift_dict.get(command) +"M\n")

        elif command in compare_dict:
            # sets pointer to first value
            self.out_file.write("@SP\n"
                                "M=M-1\n"
                                "A=M\n")
            # check if first value is positive, and if so jump
            self.out_file.write("D=M\n"
                                "@A_POS" + str(self.num_of_func) + "\n"
                                                                   "D;JGT\n")
            # check if the second value is positive, and if so jump
            self.out_file.write("@SP\n"
                                "A=M-1\n"
                                "D=M\n"
                                "@B_POS" + str(self.num_of_func) + "\n"
                                                                   "D;JGT\n")
            # a and b <= 0
            self.out_file.write("@SAME_SIGN" + str(self.num_of_func) + "\n"
                                                                       "0;JMP\n")
            # a > 0
            self.out_file.write("(A_POS" + str(self.num_of_func) + ")\n")
            # check if b is positive
            self.out_file.write("@SP\n"
                                "A=M-1\n"
                                "D=M\n"
                                "@SAME_SIGN" + str(self.num_of_func) + "\n"
                                                                       "D;JGT\n")
            # a > 0; b <= 0
            self.out_file.write("@SP\n"
                                "A=M\n"
                                "D=M\n"
                                "@TRUE" + str(self.num_of_func) + "\n"
                                                                  "D;" + compare_dict.get(
                command) + "\n"
                           "@FALSE" + str(self.num_of_func) + "\n"
                                                              "0;JMP\n")
            # b > 0, a <= 0
            self.out_file.write("(B_POS" + str(self.num_of_func) + ")\n"
                                                                   "@SP\n"
                                                                   "A=M\n"
                                                                   "D=M\n"
                                                                   "@TRUE" + str(
                self.num_of_func) + "\n"
                                    "D;" + compare_dict.get(command) + "\n"
                                                                       "@FALSE" + str(
                self.num_of_func) + "\n"
                                    "0;JMP\n")
            # a and b have the same sign, compare the numbers
            self.out_file.write("(SAME_SIGN" + str(self.num_of_func) + ")\n"
                                                                       "@SP\n"
                                                                       "A=M\n"
                                                                       "D=M-D\n"
                                                                       "@TRUE" + str(
                self.num_of_func) + "\n"
                                    "D;" + compare_dict.get(command) + "\n"
                                                                       "@FALSE" + str(
                self.num_of_func) + "\n"
                                    "0;JMP\n")
            # if the output is true
            self.out_file.write("(TRUE" + str(self.num_of_func) + ")\n"
                                                                  "@SP\n"
                                                                  "A=M-1\n"
                                                                  "M=-1\n"
                                                                  "@END" + str(
                self.num_of_func) + "\n"
                                    "0;JMP\n")
            self.out_file.write("(FALSE" + str(self.num_of_func) + ")\n"
                                                                   "@SP\n"
                                                                   "A=M-1\n"
                                                                   "M=0\n")
            # end commands and lowers value of pointer
            self.out_file.write("(END" + str(self.num_of_func) + ")\n")
            self.num_of_func += 1

        elif command in self_switch_dict:
            # sets pointer to first value
            self.out_file.write("@SP\nA=M\nA=A-1\nM=" +
                                self_switch_dict.get(command) + "M\n")

    def write_push_pop(self, command: str, segment: str, index: int) -> None:
        """Writes the assembly code that is the translation of the given 
        command, where command is either C_PUSH or C_POP.

        Args:
            command (str): "C_PUSH" or "C_POP".
            segment (str): the memory segment to operate on.
            index (int): the index in the memory segment.
        """
        # Your code goes here!
        # command_type, location, destination = command.split(SPACE)

        if command == "pop":

            # pops a value from the stack
            self.out_file.write("@SP\nA=M-1\nD=M\n")

            # lowers the value of the SP
            self.out_file.write("@SP\nM=M-1\n")

            # creates a location to hold the value
            # until we set the pointer location
            self.out_file.write("@pop_holder\nM=D\n")

            # gets the location above the stack we need to push
            self.out_file.write("@" + str(index) + "\n" + "D=A\n")

            # sets the location we need to the value from
            self.out_file.write("@LOC_HOLDER\nM=D\n")

            if segment in segment_dict:

                self.out_file.write("@" + segment_dict.get(segment)
                                    + "\nD=")
            else:
                self.out_file.write("@" + self.file_name + "." + str(index)
                                    + "\nD=")

            # checks if we are dealing with a pointer location or addressing
            if segment != "temp" and segment != "pointer":
                self.out_file.write("M\n")
            else:
                self.out_file.write("A\n")

            self.out_file.write("@LOC_HOLDER\nM=M+D\n")
            self.out_file.write("@pop_holder\nD=M\n")
            self.out_file.write("@LOC_HOLDER\nA=M\nM=D\n")

        # if we are dealing with a push command
        elif command == "push":

            # gets a value for the a destination since we cannot
            # use number bigger than one will just use it as a
            # pointer location
            self.out_file.write("@" + str(index) + "\n" + "D=A\n")

            if segment != "constant":
                # sets the location we need to the value from
                self.out_file.write("@LOC_HOLDER\nM=D\n")

                if segment in segment_dict:

                    self.out_file.write(
                        "@" + segment_dict.get(segment)
                        + "\nD=")
                else:
                    self.out_file.write(
                        "@" + self.file_name + "." + str(index)
                        + "\nD=")

                # checks if we are dealing with a pointer location or addressing
                if segment != "temp" and segment != "pointer":
                    self.out_file.write("M\n")
                else:
                    self.out_file.write("A\n")

                self.out_file.write("@LOC_HOLDER\nM=M+D\n")
                self.out_file.write("A=M\nD=M\n")

            # pushes the value of D onto the stack
            self.out_file.write("@SP\nAM=M+1\nA=A-1\nM=D\n")

            # raises the location of the stack pointer
            # self.out_file.write("@SP\nM=M+1\n")

    def close(self) -> None:
        """Closes the output file."""
        # Your code goes here!
        self.out_file.close()
