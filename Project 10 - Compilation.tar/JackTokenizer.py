"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import typing

from collections import deque

key_words_arr = ["class", "method", "function", "constructor", "int",
                 "boolean", "char", "void", "var", "static", "field", "let",
                 "do", "if", "else", "while", "return", "true", "false",
                 "null", "this"]

symbols_arr = ['{', '}', '(', ')', '[', ']', '.', ',', ';', '+',
               '-', '*', '/', '&', '&', '|', '<', '>', '=', '~']

marks_arr = [",", ";", "(", ")", "[", "]", "{", "}"]


class JackTokenizer:
    """Removes all comments from the input stream and breaks it
    into Jack language tokens, as specified by the Jack grammar.
    """

    def __init__(self, input_stream: typing.TextIO) -> None:
        """Opens the input stream and gets ready to tokenize it.

        Args:
            input_stream (typing.TextIO): input stream.
        """

        self.input_lines = input_stream.read().splitlines()
        self.tokens_arr = self.create_tokens_arr(self.input_lines)
        self.num_of_token = 0
        self.curr_token = ""

    def clean_comments_lines(self, input_lines):
        to_return = []
        is_comment_line, is_end = False, False
        for line in input_lines:
            if ('/**' in line or '/*' in line) and (
                    '*/' not in line and '**/' not in line):
                if "\"" in line:
                    s = line.find("\"")
                    e = line[s + 1:].find("\"") + s
                    if s < line.find('/**') < e or s < line.find('/*') < e:
                        to_return.append(line)
                        continue
                is_comment_line = True
            elif ('**/' in line or '*/' in line) and (
                    '/**' not in line and '/*' not in line):
                is_comment_line = True
                is_end = True
            if is_comment_line:
                if is_end:
                    is_end = False
                    is_comment_line = False
                continue
            else:
                to_return.append(line)
        return to_return

    def create_tokens_arr(self, input):
        temp_arr, tokens_arr = [], []
        input_lines = self.clean_comments_lines(input)
        for line in input_lines:
            start = line.find("\"")
            if start != -1:
                end = line[start + 1:].find("\"") + start
                if start < line.find('//') < end or \
                        start < line.find('/**') < end or \
                        start < line.find('/*') < end or \
                        start < line.find('\t') < end:
                    line = line[:start].replace('\t', "") + line[start:]
                    temp_arr.append(line)
                    continue
            asterisk = line.find("*")
            if (len(line) > 0 and line[0] == "*") or \
                    (asterisk != -1 and len(line) > 1 and line[:asterisk] ==
                     " " * asterisk and line[asterisk] == "*"):
                continue
            line = line.split('//')[0]
            line = line.split('/**')[0]
            line = line.split('/*')[0]
            line = line.replace('\t', " ")
            if len(line) < 1 or line[0] == '\n':
                continue
            temp_arr.append(line)
        for line in temp_arr:
            if "\"" not in line:
                [tokens_arr.append(token) for token in line.split(" ") if
                 token != '']
            else:
                flag = 0
                while "\"" in line:
                    a = line.find("\"")
                    if flag == 0:
                        [tokens_arr.append(token) for token in
                         line[:a].split(" ") if token != '']
                        flag = 1
                    else:
                        tokens_arr.append("\"" + line[:a] + "\"")
                    line = line[a + 1:]
                tokens_arr.append(line)
        to_return, stack = [], deque()
        for token in tokens_arr:
            if token != "" and token[-1] in marks_arr:
                while len(token) > 1 and token[-1] in marks_arr:
                    stack.append(token[-1])
                    token = token[:-1]
            for i in token:
                if i in symbols_arr and len(token) > 1 and token[0] != "\"":
                    a = token.find(i)
                    to_return.append(token[:a])
                    to_return.append(token[a:a + 1])
                    token = token[a + 1:]
            else:
                to_return.append(token)
            while stack:
                to_return.append(stack.pop())
        while '' in to_return:
            to_return.remove('')
        while ' ' in to_return:
            to_return.remove(" ")
        return to_return

    def has_more_tokens(self) -> bool:
        """Do we have more tokens in the input?

        Returns:
            bool: True if there are more tokens, False otherwise.
        """
        return self.num_of_token != len(self.tokens_arr)

    def advance(self) -> None:
        """Gets the next token from the input and makes it the current token. 
        This method should be called if has_more_tokens() is true. 
        Initially there is no current token.
        """
        # Your code goes here!
        if self.has_more_tokens():
            self.num_of_token += 1
            self.curr_token = self.tokens_arr[self.num_of_token - 1]

    def token_type(self) -> str:
        """
        Returns:
            str: the type of the current token, can be
            "KEYWORD", "SYMBOL", "IDENTIFIER", "INT_CONST", "STRING_CONST"
        """
        # Your code goes here!
        curr = self.curr_token
        if curr in key_words_arr:
            return "KEYWORD"
        elif curr in symbols_arr:
            return "SYMBOL"
        elif curr.isdigit() and 0 <= int(curr) <= 32767:
            return "INT_CONST"
        elif curr[0] == "\"":
            return "STRING_CONST"
        else:
            return "IDENTIFIER"

    def keyword(self) -> str:
        """
        Returns:
            str: the keyword which is the current token.
            Should be called only when token_type() is "KEYWORD".
            Can return "CLASS", "METHOD", "FUNCTION", "CONSTRUCTOR", "INT", 
            "BOOLEAN", "CHAR", "VOID", "VAR", "STATIC", "FIELD", "LET", "DO", 
            "IF", "ELSE", "WHILE", "RETURN", "TRUE", "FALSE", "NULL", "THIS"
        """
        # Your code goes here!
        if self.token_type() == "KEYWORD":
            return self.curr_token

    def symbol(self) -> str:
        """
        Returns:
            str: the character which is the current token.
            Should be called only when token_type() is "SYMBOL".
        """
        # Your code goes here!
        if self.token_type() == "SYMBOL":
            return self.curr_token

    def identifier(self) -> str:
        """
        Returns:
            str: the identifier which is the current token.
            Should be called only when token_type() is "IDENTIFIER".
        """
        # Your code goes here!
        if self.token_type() == "IDENTIFIER":
            return self.curr_token

    def int_val(self) -> int:
        """
        Returns:
            str: the integer value of the current token.
            Should be called only when token_type() is "INT_CONST".
        """
        # Your code goes here!
        if self.token_type() == "INT_CONST":
            return int(self.curr_token)

    def string_val(self) -> str:
        """
        Returns:
            str: the string value of the current token, without the double 
            quotes. Should be called only when token_type() is "STRING_CONST".
        """
        # Your code goes here!
        if self.token_type() == "STRING_CONST":
            return self.curr_token[1:-1]
