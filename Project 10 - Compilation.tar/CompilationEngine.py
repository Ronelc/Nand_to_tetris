"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import typing
from JackTokenizer import *

op_set = {'+', '-', '*', '/', '=', '<', '>', '&', '|'}
op_dict = {'&': '&amp;', '<': '&lt;', '>': '&gt;'}
key_word_set = {'true', 'false', 'this', 'null'}
unary_op_set = {'~', '-', '^', '#'}


# todo - add ^x - shiftLeft x, and #x - shiftRight x


class CompilationEngine:
    """Gets input from a JackTokenizer and emits its parsed structure into an
    output stream.
    """

    def __init__(self, input_stream: typing.TextIO,
                 output_stream: typing.TextIO) -> None:
        """
        Creates a new compilation engine with the given input and output. The
        next routine called must be compileClass()
        :param input_stream: The input stream.
        :param output_stream: The output stream.
        """
        # Your code goes here!
        self.tokenizer = JackTokenizer(input_stream)
        self.xml = output_stream
        self.depth = 0
        self.tokenizer.advance()
        self.compile_class()
        self.xml.close()

    def write(self, xml_t, token, flag):
        self.xml.write("\t" * self.depth + "<" + xml_t + "> " +
                       token + " </" + xml_t + ">\n")
        if flag:
            self.tokenizer.advance()

    def open(self, xml_t):
        self.xml.write("\t" * self.depth + "<" + xml_t + ">" + "\n")
        self.depth += 1

    def close(self, xml_t):
        self.depth -= 1
        self.xml.write("\t" * self.depth + "</" + xml_t + ">\n")

    def compile_class(self) -> None:
        """Compiles a complete class."""
        # Your code goes here!
        self.open("class")
        self.write("keyword", self.tokenizer.curr_token, True)
        self.write("identifier", self.tokenizer.curr_token, True)
        self.write("symbol", self.tokenizer.curr_token, True)
        key_word = self.tokenizer.curr_token
        while key_word == "field" or key_word == "static":
            self.compile_class_var_dec()
            key_word = self.tokenizer.curr_token
        while key_word == "constructor" or key_word == "method" or key_word == \
                "function":
            self.compile_subroutine()
            key_word = self.tokenizer.curr_token
        self.write("symbol", self.tokenizer.curr_token, False)
        self.close("class")

    def compile_class_var_dec(self) -> None:
        """Compiles a static declaration or a field declaration."""
        # Your code goes here!
        self.open("classVarDec")
        self.write("keyword", self.tokenizer.curr_token, True)
        if self.tokenizer.token_type() != "KEYWORD":
            self.write("identifier", self.tokenizer.curr_token, True)
        else:
            self.write("keyword", self.tokenizer.curr_token, True)
        self.write("identifier", self.tokenizer.curr_token, True)
        while self.tokenizer.curr_token != ";":
            self.write("symbol", self.tokenizer.curr_token, True)
            self.write("identifier", self.tokenizer.curr_token, True)
        self.write("symbol", self.tokenizer.curr_token, False)
        self.close("classVarDec")
        self.tokenizer.advance()

    def compile_subroutine(self) -> None:
        """Compiles a complete method, function, or constructor."""
        # Your code goes here!
        self.open("subroutineDec")
        self.write("keyword", self.tokenizer.curr_token, True)
        if self.tokenizer.token_type() != "KEYWORD":
            self.write("identifier", self.tokenizer.curr_token, True)
        else:
            self.write("keyword", self.tokenizer.curr_token, True)
        self.write("identifier", self.tokenizer.curr_token, True)
        self.write("symbol", self.tokenizer.curr_token, False)
        self.compile_parameter_list()
        self.write("symbol", self.tokenizer.curr_token, True)
        self.compile_body_subroutine()
        self.close("subroutineDec")

    def compile_body_subroutine(self):
        self.open("subroutineBody")
        self.write("symbol", self.tokenizer.curr_token, True)
        while self.tokenizer.curr_token == "var":
            self.compile_var_dec()
        if self.tokenizer.curr_token != "}":
            self.compile_statements()
        self.write("symbol", self.tokenizer.curr_token, True)
        self.close("subroutineBody")

    def compile_parameter_list(self) -> None:
        """Compiles a (possibly empty) parameter list, not including the 
        enclosing "()".
        """
        # Your code goes here!
        self.open("parameterList")
        self.tokenizer.advance()
        while self.tokenizer.curr_token != ")":
            if self.tokenizer.token_type() != "KEYWORD":
                self.write("identifier", self.tokenizer.curr_token, True)
            else:
                self.write("keyword", self.tokenizer.curr_token, True)
            self.write("identifier", self.tokenizer.curr_token, True)
            if self.tokenizer.curr_token == ",":
                self.write("symbol", self.tokenizer.curr_token, True)
        self.close("parameterList")

    def compile_var_dec(self) -> None:
        """Compiles a var declaration."""
        # Your code goes here!
        self.open("varDec")
        self.write("keyword", self.tokenizer.curr_token, True)
        if self.tokenizer.token_type() != "KEYWORD":
            self.write("identifier", self.tokenizer.curr_token, True)
        else:
            self.write("keyword", self.tokenizer.curr_token, True)
        while self.tokenizer.curr_token != ";":
            self.write("identifier", self.tokenizer.curr_token, True)
            if self.tokenizer.curr_token == ",":
                self.write("symbol", self.tokenizer.curr_token, True)
        self.write("symbol", self.tokenizer.curr_token, True)
        self.close("varDec")

    def compile_statements(self) -> None:
        """Compiles a sequence of statements, not including the enclosing 
        "{}".
        """
        # Your code goes here!
        self.open("statements")
        while self.tokenizer.curr_token != '}':
            if self.tokenizer.curr_token == ";":
                a = True
            statement_type = self.tokenizer.keyword()
            if statement_type == "let":
                self.compile_let()
            elif statement_type == "if":
                self.compile_if()
            elif statement_type == "while":
                self.compile_while()
            elif statement_type == "do":
                self.compile_do()
            elif statement_type == "return":
                self.compile_return()
        self.close("statements")

    def subroutine_call(self):
        if self.tokenizer.curr_token == '.':
            self.write("symbol", self.tokenizer.curr_token, True)
            self.write("identifier", self.tokenizer.curr_token, True)
        self.write("symbol", self.tokenizer.curr_token, True)
        self.compile_expression_list()
        self.write("symbol", self.tokenizer.curr_token, True)

    def compile_do(self) -> None:
        """Compiles a do statement."""
        self.open("doStatement")
        self.write("keyword", self.tokenizer.curr_token, True)
        self.write("identifier", self.tokenizer.curr_token, True)
        self.subroutine_call()
        self.write("symbol", self.tokenizer.curr_token, False)
        self.close("doStatement")
        self.tokenizer.advance()

    def compile_let(self) -> None:
        """Compiles a let statement."""
        self.open("letStatement")
        self.write("keyword", self.tokenizer.curr_token, True)
        self.write("identifier", self.tokenizer.curr_token, True)
        if self.tokenizer.curr_token == '[':
            self.write("symbol", self.tokenizer.curr_token, True)
            self.compile_expression()
            self.write("symbol", self.tokenizer.curr_token, True)
        self.write("symbol", self.tokenizer.curr_token, True)
        self.compile_expression()
        self.write("symbol", self.tokenizer.curr_token, False)
        self.close("letStatement")
        self.tokenizer.advance()

    def compile_while(self) -> None:
        """Compiles a while statement."""
        self.open("whileStatement")
        self.write("keyword", self.tokenizer.curr_token, True)
        self.write("symbol", self.tokenizer.curr_token, True)
        self.compile_expression()
        self.write("symbol", self.tokenizer.curr_token, True)
        self.write("symbol", self.tokenizer.curr_token, True)
        self.compile_statements()
        self.write("symbol", self.tokenizer.curr_token, False)
        self.close("whileStatement")
        self.tokenizer.advance()

    def compile_return(self) -> None:
        """Compiles a return statement."""
        self.open("returnStatement")
        self.write("keyword", self.tokenizer.curr_token, True)
        if self.tokenizer.curr_token != ';':
            self.compile_expression()
        self.write("symbol", self.tokenizer.curr_token, False)
        self.close("returnStatement")
        self.tokenizer.advance()

    def compile_if(self) -> None:
        """Compiles a if statement, possibly with a trailing else clause."""
        self.open("ifStatement")
        self.write("keyword", self.tokenizer.curr_token, True)

        self.write("symbol", self.tokenizer.curr_token, True)
        self.compile_expression()
        self.write("symbol", self.tokenizer.curr_token, True)
        self.write("symbol", self.tokenizer.curr_token, True)
        self.compile_statements()
        self.write("symbol", self.tokenizer.curr_token, True)
        if self.tokenizer.curr_token == 'else':
            self.write("keyword", self.tokenizer.curr_token, True)
            self.write("symbol", self.tokenizer.curr_token, True)
            self.compile_statements()
            self.write("symbol", self.tokenizer.curr_token, True)
        self.close("ifStatement")

    def compile_expression(self) -> None:
        """Compiles an expression."""
        self.open("expression")
        self.compile_term()
        while self.tokenizer.curr_token in op_set:
            if self.tokenizer.curr_token in op_dict:
                self.write("symbol", op_dict.get(self.tokenizer.curr_token),
                           True)
            else:
                self.write("symbol", self.tokenizer.curr_token, True)
            self.compile_term()
        self.close("expression")

    def compile_term(self) -> None:
        """Compiles a term. 
        This routine is faced with a slight difficulty when
        trying to decide between some of the alternative parsing rules.
        Specifically, if the current token is an identifier, the routing must
        distinguish between a variable, an array entry, and a subroutine call.
        A single look-ahead token, which may be one of "[", "(", or "." suffice
        to distinguish between the three possibilities. Any other token is not
        part of this term and should not be advanced over.
        """
        self.open("term")
        token_type = self.tokenizer.token_type()
        if token_type == "INT_CONST":
            self.write("integerConstant", self.tokenizer.curr_token, True)
        elif token_type == "STRING_CONST":
            self.write("stringConstant", self.tokenizer.curr_token[1:-1], True)
        elif self.tokenizer.curr_token in key_word_set:
            self.write("keyword", self.tokenizer.curr_token, True)
        elif self.tokenizer.curr_token == '(':
            self.write("symbol", self.tokenizer.curr_token, True)
            self.compile_expression()
            self.write("symbol", self.tokenizer.curr_token, True)
        elif self.tokenizer.curr_token in unary_op_set:
            self.write("symbol", self.tokenizer.curr_token, True)
            self.compile_term()
        else:
            self.write("identifier", self.tokenizer.curr_token, True)
            if self.tokenizer.curr_token == '[':
                self.write("symbol", self.tokenizer.curr_token, True)
                self.compile_expression()
                self.write("symbol", self.tokenizer.curr_token, True)
            elif self.tokenizer.curr_token == '(' or self.tokenizer.curr_token \
                    == '.':
                self.subroutine_call()
        self.close("term")

    def compile_expression_list(self) -> None:
        """Compiles a (possibly empty) comma-separated list of expressions."""
        self.open("expressionList")
        if self.tokenizer.curr_token != ')':
            self.compile_expression()
            while self.tokenizer.curr_token == ',':
                self.write("symbol", self.tokenizer.curr_token, True)
                self.compile_expression()
        self.close("expressionList")
