"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import typing
from JackTokenizer import *
from JackTokenizer import JackTokenizer
from SymbolTable import SymbolTable
from VMWriter import VMWriter

op_set = {'+', '-', '*', '/', '=', '<', '>', '&', '|'}
op_dict = {'+': 'ADD', '-': 'SUB', '*': ("Math.multiply", 2),
           '/': ("Math.divide", 2), '&': "AND", '|': "OR", '<': 'LT',
           '>': "GT", '=': "EQ"}

unary_op_dict = {'~': 'NOT', '-': 'NEG', '^': "SHIFTLEFT", '#': "SHIFTRIGHT"}
type_dict = {'FIELD': 'THIS', "STATIC": "STATIC", "VAR": 'LOCAL', "ARG": "ARG"}
const_dict = {'true': ("CONST", 0), 'false': ("CONST", 0),
              'null': ("CONST", 0), 'this': ("POINTER", 0)}


class CompilationEngine:
    """Gets input from a JackTokenizer and emits its parsed structure into an
    output stream.
    """

    def __init__(self, input_stream: typing.TextIO,
                 output_stream: typing.TextIO) -> None:
        """
        Creates a new compilation engine with the given input and output. The
        next routine called must be compileClass()
        :param input_stream: The input stream.
        :param output_stream: The output stream.
        """
        self.tokenizer = JackTokenizer(input_stream)
        self.symbol_table = SymbolTable()
        self.vm_writer = VMWriter(output_stream)
        self.curr_sub_name = ""
        self.class_name = ""
        self.loops_counter = {"func": 0, "while": 0, "if": 0}
        self.tokenizer.advance()
        self.compile_class()
        self.vm_writer.close()

    def compile_class(self) -> None:
        """Compiles a complete class."""
        self.tokenizer.advance()
        self.class_name = self.tokenizer.curr_token
        self.tokenizer.advance()
        self.tokenizer.advance()
        key_word = self.tokenizer.curr_token
        while key_word == "field" or key_word == "static":
            self.compile_class_var_dec()
            key_word = self.tokenizer.curr_token
        subroutine_arr = ["constructor", "method", "function"]
        while key_word in subroutine_arr:
            self.compile_subroutine()
            key_word = self.tokenizer.curr_token

    def define_table(self, kind: str) -> str:
        """
        Args:
            kind: the kind of token type.
        Returns: var_type
        """
        var_type = ""
        if self.tokenizer.token_type() != "KEYWORD":
            var_type = self.tokenizer.identifier()
        else:
            var_type = self.tokenizer.keyword()
        self.tokenizer.advance()
        if self.tokenizer.token_type() == "KEYWORD":
            var_name = self.tokenizer.keyword()
        else:
            var_name = self.tokenizer.identifier()
        self.symbol_table.define(var_name, var_type, kind)
        self.tokenizer.advance()
        return var_type

    def compile_class_var_dec(self) -> None:
        """Compiles a static declaration or a field declaration."""
        var_kind = self.tokenizer.keyword()
        self.tokenizer.advance()
        var_type = self.define_table(var_kind)
        while self.tokenizer.curr_token != ";":
            self.tokenizer.advance()
            self.symbol_table.define(self.tokenizer.curr_token, var_type,
                                     var_kind)
            self.tokenizer.advance()
        self.tokenizer.advance()

    def compile_subroutine(self) -> None:
        """Compiles a complete method, function, or constructor."""
        self.symbol_table.start_subroutine()
        sub_type = self.tokenizer.keyword()
        self.tokenizer.advance()
        self.tokenizer.advance()
        self.curr_sub_name = self.tokenizer.identifier()
        self.tokenizer.advance()
        if sub_type == "method":
            self.symbol_table.define("this", self.class_name, "ARG")
        self.compile_parameter_list()
        self.tokenizer.advance()
        self.compile_body_subroutine(sub_type)

    def compile_body_subroutine(self, sub_type: str):
        """
        the method compiles the subroutine body
        :return: none
        """
        self.tokenizer.advance()
        while self.tokenizer.curr_token == "var":
            self.compile_var_dec()

        self.vm_writer.write_function(
            self.class_name + '.' + self.curr_sub_name,
            self.symbol_table.var_count("VAR"))

        if sub_type == "method":
            self.vm_writer.write_push("ARG", 0)
            self.vm_writer.write_pop("POINTER", 0)

        if sub_type == "constructor":
            self.vm_writer.write_push("CONST",
                                      self.symbol_table.var_count("FIELD"))
            self.vm_writer.write_call("Memory.alloc", 1)
            self.vm_writer.write_pop("POINTER", 0)
        if self.tokenizer.curr_token != "}":
            self.compile_statements()
        self.tokenizer.advance()

    def compile_parameter_list(self) -> None:
        """Compiles a (possibly empty) parameter list, not including the
        enclosing "()".
        """
        self.tokenizer.advance()
        while self.tokenizer.curr_token != ")":
            self.define_table("ARG")
            if self.tokenizer.curr_token == ",":
                self.tokenizer.advance()

    def compile_var_dec(self) -> None:
        """Compiles a var declaration."""
        self.tokenizer.advance()
        if self.tokenizer.token_type() != "KEYWORD":
            var_type = self.tokenizer.identifier()
        else:
            var_type = self.tokenizer.keyword()
        self.tokenizer.advance()
        while self.tokenizer.curr_token != ";":
            var_name = self.tokenizer.identifier()
            self.symbol_table.define(var_name, var_type, "VAR")
            self.tokenizer.advance()
            if self.tokenizer.curr_token == ",":
                self.tokenizer.advance()
        self.tokenizer.advance()

    def compile_statements(self) -> None:
        """Compiles a sequence of statements, not including the enclosing "{}".
        """
        while self.tokenizer.curr_token != '}':
            statement_type = self.tokenizer.keyword()
            if statement_type == "let":
                self.compile_let()
            elif statement_type == "if":
                self.compile_if()
            elif statement_type == "while":
                self.compile_while()
            elif statement_type == "do":
                self.compile_do()
            elif statement_type == "return":
                self.compile_return()

    def subroutine_call(self, identifier):
        func_name = self.class_name + "." + identifier
        num_of_args = 0
        if self.tokenizer.curr_token == '.':
            if self.symbol_table.type_of(identifier) is not None:
                func_name = self.symbol_table.type_of(identifier)
                self.tokenizer.advance()
                func_name = str(func_name) + "." + self.tokenizer.identifier()
                self.tokenizer.advance()
                segment = type_dict[self.symbol_table.kind_of(identifier)]
                idx = self.symbol_table.index_of(identifier)
                self.vm_writer.write_push(segment, idx)
                num_of_args += 1
            else:
                self.tokenizer.advance()
                func_name = identifier + "." + self.tokenizer.identifier()
                self.tokenizer.advance()
        else:
            self.vm_writer.write_push("POINTER", 0)
            num_of_args += 1
        self.tokenizer.advance()
        num_of_args += self.compile_expression_list()
        self.tokenizer.advance()
        self.vm_writer.write_call(func_name, num_of_args)

    def compile_do(self) -> None:
        """Compiles a do statement."""
        self.tokenizer.advance()
        func_name = self.tokenizer.identifier()
        self.tokenizer.advance()
        self.subroutine_call(func_name)
        self.vm_writer.write_pop("TEMP", 0)
        self.tokenizer.advance()

    def compile_let(self) -> None:
        self.tokenizer.advance()
        var_name = self.tokenizer.identifier()
        var_index = self.symbol_table.index_of(var_name)
        var_kind = type_dict[self.symbol_table.kind_of(var_name)]
        self.tokenizer.advance()
        curr_token = self.tokenizer.curr_token
        if curr_token == '[':
            self.vm_writer.write_push(var_kind, var_index)
            self.tokenizer.advance()
            self.compile_expression()
            self.tokenizer.advance()
            self.vm_writer.write_arithmetic("ADD")
        self.tokenizer.advance()
        self.compile_expression()
        if curr_token == "[":
            self.vm_writer.write_pop("TEMP", 0)
            self.vm_writer.write_pop("POINTER", 1)
            self.vm_writer.write_push("TEMP", 0)
            self.vm_writer.write_pop("THAT", 0)
        else:
            self.vm_writer.write_pop(var_kind, var_index)
        self.tokenizer.advance()

    def compile_return(self) -> None:
        """Compiles a return statement."""
        self.tokenizer.advance()
        if self.tokenizer.curr_token == ';':
            self.vm_writer.write_push("CONST", 0)
        else:
            self.compile_expression()
        self.tokenizer.advance()
        self.vm_writer.write_return()

    def compile_if_while(self, loop_type) -> None:
        counter = str(self.loops_counter[loop_type])
        self.loops_counter[loop_type] += 1
        if loop_type == "while":
            self.vm_writer.write_label("While_" + counter)
        self.tokenizer.advance()
        self.tokenizer.advance()
        self.compile_expression()
        if loop_type == "while":
            self.tokenizer.advance()
        self.vm_writer.write_arithmetic("NOT")
        if loop_type == "while":
            self.vm_writer.write_if("End_While_" + counter)
        else:
            self.vm_writer.write_if("ELSE_" + counter)
            self.tokenizer.advance()
        self.tokenizer.advance()
        self.compile_statements()
        if loop_type == "while":
            self.vm_writer.write_goto("While_" + counter)
            self.vm_writer.write_label("End_While_" + counter)
            self.tokenizer.advance()
        else:
            self.vm_writer.write_goto("END_IF_" + counter)
            self.tokenizer.advance()
            self.vm_writer.write_label("ELSE_" + counter)
            if self.tokenizer.curr_token == 'else':
                self.tokenizer.advance()
                self.tokenizer.advance()
                self.compile_statements()
                self.tokenizer.advance()
            self.vm_writer.write_label("END_IF_" + counter)

    def compile_while(self) -> None:
        self.compile_if_while("while")

    def compile_if(self) -> None:
        self.compile_if_while("if")

    def compile_expression(self) -> None:
        self.compile_term()
        while self.tokenizer.curr_token in op_set:
            math_token = self.tokenizer.curr_token
            self.tokenizer.advance()
            self.compile_term()
            math = ["*", "/"]
            if math_token not in math:
                self.vm_writer.write_arithmetic(op_dict.get(math_token))
            else:
                self.vm_writer.write_call((op_dict.get(math_token))[0],
                                          int((op_dict.get(math_token))[1]))

    def compile_term(self) -> None:
        token_type = self.tokenizer.token_type()
        if token_type == "INT_CONST":
            self.vm_writer.write_push("CONST", self.tokenizer.int_val())
            self.tokenizer.advance()
        elif token_type == "STRING_CONST":
            string_val = self.tokenizer.string_val()
            self.vm_writer.write_push("CONST", len(string_val))
            self.vm_writer.write_call("String.new", 1)
            for char in string_val:
                self.vm_writer.write_push("CONST", ord(char))
                self.vm_writer.write_call("String.appendChar", 2)
            self.tokenizer.advance()
        elif self.tokenizer.curr_token in const_dict:
            segment, idx = const_dict[self.tokenizer.curr_token]
            self.vm_writer.write_push(segment, idx)
            if self.tokenizer.curr_token == 'true':
                self.vm_writer.write_arithmetic('NOT')
            self.tokenizer.advance()
        elif self.tokenizer.curr_token == '(':
            self.tokenizer.advance()
            self.compile_expression()
            self.tokenizer.advance()
        elif self.tokenizer.curr_token in unary_op_dict:
            op_command = unary_op_dict[self.tokenizer.curr_token]
            self.tokenizer.advance()
            self.compile_term()
            self.vm_writer.write_arithmetic(op_command)
        else:
            arr = ["(", "."]
            var_name = self.tokenizer.identifier()
            self.tokenizer.advance()
            if self.tokenizer.curr_token == '[':
                var_kind = type_dict[self.symbol_table.kind_of(var_name)]
                var_index = self.symbol_table.index_of(var_name)
                self.vm_writer.write_push(var_kind, var_index)
                self.tokenizer.advance()
                self.compile_expression()
                self.vm_writer.write_arithmetic("ADD")
                self.vm_writer.write_pop("POINTER", 1)
                self.vm_writer.write_push("THAT", 0)
                self.tokenizer.advance()
            elif self.tokenizer.curr_token in arr:
                self.subroutine_call(var_name)
            else:
                self.vm_writer.write_push(
                    type_dict[self.symbol_table.kind_of(var_name)],
                    self.symbol_table.index_of(var_name))

    def compile_expression_list(self) -> int:
        """
        count the num of vars in exp
        Returns: num of vars
        """
        counter = 0
        if self.tokenizer.curr_token != ')':
            self.compile_expression()
            counter += 1
            while self.tokenizer.curr_token == ',':
                self.tokenizer.advance()
                self.compile_expression()
                counter += 1
        return counter
