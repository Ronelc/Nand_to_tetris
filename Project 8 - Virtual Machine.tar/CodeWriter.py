"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import os
import typing
from Parser import *

operator_dict = {
    "and": "&",
    "add": "+",
    "or": "|",
    "sub": "-"
}

shift_dict = {
    "shiftleft": "<<",
    "shiftright": ">>"
}

compare_dict = {
    "eq": "JEQ",
    "gt": "JLT",
    "lt": "JGT"
}

self_switch_dict = {
    "neg": "-",
    "not": "!"
}

segment_dict = {
    "local": "LCL",
    "argument": "ARG",
    "this": "THIS",
    "that": "THAT",
    "temp": "R5",
    "pointer": "R3"
}


class CodeWriter:
    """Translates VM commands into Hack assembly code."""

    def __init__(self, output_stream: typing.TextIO) -> None:
        """Initializes the CodeWriter.

        Args:
            output_stream (typing.TextIO): output stream.
        """
        # Your code goes here!
        self.out_file = output_stream
        self.label_counter = 0
        self.file_name = ""

    def write_init(self):
        """
        this function write the initial part of the code
        :return: none
        """
        # sets the pointer to the first part of the stack
        self.out_file.write("@256\nD=A\n@SP\nM=D\n")
        self.write_call("Sys.init", 0)

    def read_file(self, input_file: typing.TextIO):
        p = Parser(input_file)
        # c_type = p.command_type()
        while p.has_more_commands():
            p.advance()
            c_type = p.command_type()
            if c_type == "C_ARITHMETIC":
                self.write_arithmetic(p.arg1())
            elif c_type == "C_PUSH" or c_type == "C_POP":
                self.write_push_pop(c_type, p.arg1(), p.arg2())
            elif c_type == "C_FUNCTION":
                self.write_function(p.arg1(), p.arg2())
            elif c_type == "C_LABEL":
                self.write_label(p.arg1())
            elif c_type == "C_IF":
                self.write_if_goto(p.arg1())
            elif c_type == "C_RETURN":
                self.write_return()
            elif c_type == "C_CALL":
                self.write_call(p.arg1(), p.arg2())
            elif c_type == "C_GOTO":
                self.write_goto(p.arg1())

    def set_file_name(self, filename: str) -> None:
        """Informs the code writer that the translation of a new VM file is 
        started.

        Args:
            filename (str): The name of the VM file.
        """
        self.file_name, input_extension = os.path.splitext(
            os.path.basename(filename))

    def write_arithmetic(self, command: str) -> None:
        """Writes the assembly code that is the translation of the given
        arithmetic command.

        Args:
            command (str): an arithmetic command.
        """
        # Your code goes here!

        if command in operator_dict:

            # sets pointer to first value
            self.out_file.write("@SP\n"
                                "A=M\n"
                                "A=A-1\n")

            # saves first value and goes to next value and
            # adds it to next value
            self.out_file.write("D=M\n"
                                "A=A-1\n"
                                "M=M" + operator_dict.get(command) + "D\n")

            # lowers value of pointer
            self.out_file.write("@SP\n"
                                "M=M-1\n")

        elif command in shift_dict:

            # sets pointer to first value
            self.out_file.write("@SP\n"
                                "A=M\n"
                                "A=A-1\n")

            # saves first value and goes to next value and
            # adds it to next value
            self.out_file.write(
                "M=" + shift_dict.get(command) + "M\n")

        elif command in compare_dict:
            # sets pointer to first value
            self.out_file.write("@SP\n"
                                "M=M-1\n"
                                "A=M\n")
            # check if first value is positive, and if so jump
            self.out_file.write("D=M\n"
                                "@A_POS" + str(self.label_counter) + "\n"
                                                                "D;JGT\n")
            # check if the second value is positive, and if so jump
            self.out_file.write("@SP\n"
                                "A=M-1\n"
                                "D=M\n"
                                "@B_POS" + str(self.label_counter) + "\n"
                                                                     "D;JGT\n")
            # a and b <= 0
            self.out_file.write("@SAME_SIGN" + str(self.label_counter) + "\n"
                                                                         "0;JMP\n")
            # a > 0
            self.out_file.write("(A_POS" + str(self.label_counter) + ")\n")
            # check if b is positive
            self.out_file.write("@SP\n"
                                "A=M-1\n"
                                "D=M\n"
                                "@SAME_SIGN" + str(self.label_counter) + "\n"
                                                                         "D;JGT\n")
            # a > 0; b <= 0
            self.out_file.write("@SP\n"
                                "A=M\n"
                                "D=M\n"
                                "@TRUE" + str(self.label_counter) + "\n"
                                                                    "D;" + compare_dict.get(
                command) + "\n"
                           "@FALSE" + str(self.label_counter) + "\n"
                                                                "0;JMP\n")
            # b > 0, a <= 0
            self.out_file.write("(B_POS" + str(self.label_counter) + ")\n"
                                                                     "@SP\n"
                                                                     "A=M\n"
                                                                     "D=M\n"
                                                                     "@TRUE" + str(
                self.label_counter) + "\n"
                                      "D;" + compare_dict.get(command) + "\n"
                                                                         "@FALSE" + str(
                self.label_counter) + "\n"
                                      "0;JMP\n")
            # a and b have the same sign, compare the numbers
            self.out_file.write("(SAME_SIGN" + str(self.label_counter) + ")\n"
                                                                         "@SP\n"
                                                                         "A=M\n"
                                                                         "D=M-D\n"
                                                                         "@TRUE" + str(
                self.label_counter) + "\n"
                                      "D;" + compare_dict.get(command) + "\n"
                                                                         "@FALSE" + str(
                self.label_counter) + "\n"
                                      "0;JMP\n")
            # if the output is true
            self.out_file.write("(TRUE" + str(self.label_counter) + ")\n"
                                                                    "@SP\n"
                                                                    "A=M-1\n"
                                                                    "M=-1\n"
                                                                    "@END" + str(
                self.label_counter) + "\n"
                                      "0;JMP\n")
            self.out_file.write("(FALSE" + str(self.label_counter) + ")\n"
                                                                     "@SP\n"
                                                                     "A=M-1\n"
                                                                     "M=0\n")
            # end commands and lowers value of pointer
            self.out_file.write("(END" + str(self.label_counter) + ")\n")
            self.label_counter += 1

        elif command in self_switch_dict:
            # sets pointer to first value
            self.out_file.write("@SP\nA=M\nA=A-1\nM=" +
                                self_switch_dict.get(command) + "M\n")

    def write_push_pop(self, command: str, segment: str, index: int) -> None:
        """Writes the assembly code that is the translation of the given
        command, where command is either C_PUSH or C_POP.

        Args:
            command (str): "C_PUSH" or "C_POP".
            segment (str): the memory segment to operate on.
            index (int): the index in the memory segment.
        """
        # Your code goes here!
        # command_type, location, destination = command.split(SPACE)

        if command == "C_POP":

            # pops a value from the stack
            self.out_file.write("@SP\nA=M-1\nD=M\n")

            # lowers the value of the SP
            self.out_file.write("@SP\nM=M-1\n")

            # if we are dealing with static no point of manipulating pointers
            if segment == "static":
                self.out_file.write("@" + self.file_name + "." + str(index)
                                    + "\nM=D\n")
                return

            # creates a location to hold the value
            # until we set the pointer location
            self.out_file.write("@pop_holder\nM=D\n")

            # gets the location above the stack we need to push
            self.out_file.write("@" + str(index) + "\n" + "D=A\n")

            # sets the location we need to the value from
            self.out_file.write("@LOC_HOLDER\nM=D\n")

            if segment in segment_dict:

                self.out_file.write("@" + segment_dict.get(segment)
                                    + "\nD=")
            else:
                self.out_file.write("@" + self.file_name + "." + str(index)
                                    + "\nD=")

            # checks if we are dealing with a pointer location or addressing
            if segment != "temp" and segment != "pointer":
                self.out_file.write("M\n")
            else:
                self.out_file.write("A\n")

            self.out_file.write("@LOC_HOLDER\nM=M+D\n")
            self.out_file.write("@pop_holder\nD=M\n")
            self.out_file.write("@LOC_HOLDER\nA=M\nM=D\n")

        # if we are dealing with a push command
        elif command == "C_PUSH":
            if segment == "static":
                self.out_file.write("@" + self.file_name + "." + str(index)
                                    + "\nD=M\n")
            else:
                # gets a value for the a destination since we cannot
                # use number bigger than one will just use it as a
                # pointer location
                self.out_file.write("@" + str(index) + "\n" + "D=A\n")

                if segment != "constant":
                    # sets the location we need to the value from
                    self.out_file.write("@LOC_HOLDER\nM=D\n")

                    if segment in segment_dict:

                        self.out_file.write(
                            "@" + segment_dict.get(segment)
                            + "\nD=")
                    else:
                        self.out_file.write(
                            "@" + self.file_name + "." + str(index)
                            + "\nD=")

                    # checks if we are dealing with a pointer location or addressing
                    if segment != "temp" and segment != "pointer":
                        self.out_file.write("M\n")
                    else:
                        self.out_file.write("A\n")

                    self.out_file.write("@LOC_HOLDER\nM=M+D\n")
                    self.out_file.write("A=M\nD=M\n")

            # # pushes the value of D onto the stack
            # self.out_file.write("@SP\nAM=M+1\nA=A-1\nM=D\n")

            # pushes the value of D onto the stack
            self.out_file.write("@SP\nA=M\nM=D\n")

            # raises the location of the stack pointer
            self.out_file.write("@SP\nM=M+1\n")

    def write_label(self, label_name):
        """
        Args:
        label_name: the label to write
        :return: none
        """

        # writes the functions name
        self.out_file.write("(" + str(label_name) + ")\n")

    def write_if_goto(self, jump_to):
        """
        writes the if function
        :param jump_to: the new location
        :return: none
        """

        # gets the value from the stack pointer and lowers it
        self.out_file.write("@SP\n"
                            "A=M-1\n"
                            "D=M\n"
                            "@SP\n"
                            "M=M-1\n")

        # jumps based on if the previous place in the stack is negative
        self.out_file.write("@" + jump_to + "\nD,JNE\n")

    def write_goto(self, jump_to):
        """
        writes the goto command
        :param jump_to: the new location
        :return: none
        """

        # jump to new location
        self.out_file.write("@" + jump_to + "\n0;JMP\n")

    def write_function(self, func_name, num_of_args):
        """
        Initializes a space in the stack as the number of arguments of the
        function
        :param func_name: the function name
        :param num_of_args: the amount of arguments it receive
        :return: none
        """

        # writes the functions name as a label
        self.write_label(func_name)
        for i in range(int(num_of_args)):
            # fill with zero and raise stack pointer
            self.out_file.write("@SP\n"
                                "A=M\n"
                                "M=0\n"
                                "@SP\n"
                                "M=M+1\n")
        # todo
        self.label_counter += 1

    def write_return(self):
        """
        write the return function to return all back to previous state
        :return: none
        """

        # holds the value in the local
        self.out_file.write("@LCL\nD=M\n@R11\nM=D\n")

        # saves the value of where the return address
        self.out_file.write("@5\nA=D-A\nD=M\n@R12\nM=D\n")

        # saves the value of where the last function ended
        self.out_file.write("@ARG\nD=M\n@0\nD=D+A\n@R13\nM=D\n")

        # saves the last value of the stack pointer as in
        # the return val location
        self.out_file.write("@SP\nM=M-1\nA=M\nD=M\n@R13\nA=M\nM=D\n")

        # sets the stack pointer to the new location
        self.out_file.write("@ARG\nD=M\n@SP\nM=D+1\n")

        # todo - there is a bug at this and that
        locations = ["@THAT", "@THIS", "@ARG", "@LCL"]
        for location in locations:
            self.out_file.write(
                "@R11\nD=M-1\nM=D\nA=M\nD=M\n" + location + "\nM=D\n")
            # jumps to the return address
        self.out_file.write("@R12\nA=M\n0;JMP\n")

    def write_call(self, func_name, num_of_args):
        """
        writes a call to a function
        :param func_name: the name of the function we want to go to
        :param num_of_args: the amount of arguments the function will take
        :return: none
        """

        # sets the location line the program needs to return too
        self.out_file.write("@RETURN_" + str(self.label_counter) +
                            "\nD=A\n@SP\nA=M\nM=D\n@SP\nM=M+1\n")

        # save the pointers
        locations = ["@LCL", "@ARG", "@THIS", "@THAT"]
        for location in locations:
            self.out_file.write(
                location + "\nD=M\n@SP\nA=M\nM=D\n@SP\nM=M+1\n")

        # resets the arguments and local location
        self.out_file.write("@SP\nD=M\n@5\nD=D-A\n@" + str(num_of_args)
                            + "\nD=D-A\n@ARG\nM=D\n@SP\nD=M\n@LCL\nM=D\n")

        # has the function call the main loop
        self.out_file.write("@" + func_name + "\n0;JMP\n")

        # the next line to commit
        self.out_file.write("(RETURN_" + str(self.label_counter) + ")\n")
        self.label_counter += 1

    def close(self) -> None:
        """Closes the output file."""
        self.out_file.close()
